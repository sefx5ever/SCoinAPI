# from src import centralbank

# ck = centralbank.Central_Bank()
# res = ck.send_token('nUjymFTzrJcuqizbswdKACJtpRwMZtEkwXzQDxBk','cb','marmotbank',40)
# res = ck.set_central_bank('marmotbank','jiayingfengtingweijie')
# res = ck.create_did('marmotbank','jiayingfengtingweijie')
# res = ck.get_balance('sefx2ever')
# print(res)